define([
  'app/bindings/navigate',
  'app/bindings/loadingBtn',
  'app/bindings/translate'
], function() {});
