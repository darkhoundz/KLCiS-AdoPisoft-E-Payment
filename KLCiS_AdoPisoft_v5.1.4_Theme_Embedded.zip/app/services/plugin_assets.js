define([
  'json!/client/plugins/assets.json'
], function(assets) {
  return assets;
});
